#!/bin/bash
cd /home/site/wwwroot
npm install
node index.js
